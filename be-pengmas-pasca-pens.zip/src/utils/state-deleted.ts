const ARCHIVED = {
  isArchived: true
}
const NOT_ARCHIVED = {
  isArchived: false
}

export {ARCHIVED, NOT_ARCHIVED}