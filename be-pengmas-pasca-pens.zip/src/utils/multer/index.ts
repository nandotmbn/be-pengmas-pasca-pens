export { uploadImage } from './upload-image.multer';
export { uploadDocument } from './upload-document.multer';
