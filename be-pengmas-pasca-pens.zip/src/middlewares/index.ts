export { checkSuperAdmin } from './check-super-admin.middlewares';
export { checkAdmin } from './check-admin.middlewares';
export { checkLecturer } from './check-lecturer.middlewares';
export { checkStaff } from './check-staff.middlewares';
