/* eslint-disable @typescript-eslint/no-unused-vars */
interface MessageInterface {
  statusCode: number;
  message: string;
  data: unknown;
}
