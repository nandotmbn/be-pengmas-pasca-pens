/* eslint-disable @typescript-eslint/no-unused-vars */
interface GetAllNewsInterface {
  roleName: string;
}

interface GetAllNewsRequestQuery {
  page: number;
  limit: number;
}

interface GetAllNewsRequestParams {
  roles_id: string;
}

interface GetAllNewsResponseBody {
  null: null;
}

interface GetAllNewsRequestBody {
  null: null;
}
