export { router as AuthRouter } from './auth.routes';
export { router as UserRouter } from './user.routes';
export { router as MonitorRouter } from './monitor.routes';
export { router as SampleRouter } from './sample.routes';
export { router as CityRouter } from './city.routes';
export { router as ProvinceRouter } from './provinces.routes';
export { router as PondsRouter } from './ponds.routes';
export { router as PoolsRouter } from './pools.routes';
