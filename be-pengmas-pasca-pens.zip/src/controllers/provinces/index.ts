export { getAllProvinces } from './get-all.provinces.controllers';
